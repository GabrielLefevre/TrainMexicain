package trainMexicain;

import static org.junit.Assert.*;


import org.junit.Test;

public class JeuMexicainTest {

	Pile p = new Pile();
	@Test
	public void testJeuMexicain() {
		JeuMexicain jeu = new JeuMexicain(p);
		assertNotNull(jeu);
	}


	@Test
	public void testGetDominoDepart() {
		Domino d = new Domino(1,3);
		assertEquals(d.getPartG(),d.getPartD());
	}


}
