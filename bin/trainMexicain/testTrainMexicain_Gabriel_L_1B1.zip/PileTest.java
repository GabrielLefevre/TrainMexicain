package trainMexicain;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class PileTest {

	@Test
	public void testPile() {
		ArrayList<Domino> n = new ArrayList<Domino>();
		n.add(new Domino(1,2));
		assertEquals(n,);
	}



}
