package trainMexicain;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class JoueurTest {

	protected Pile p = new Pile();
	protected Scanner s = new Scanner(System.in);
	@Test
	public void testJoueur() {
		Joueur j = new Joueur("s", p);
		assertEquals(j.getNom(), p);
	}

	@Test
	public void testGetNom() {
		Joueur j = new Joueur("s", p);
		assertEquals(j.getNom(), p);
	}

	

	@Test
	public void testRemplirMainJoueur() {
		Joueur j = new Joueur("s",p);
		j.remplirMainJoueur();
		assertNotNull(j.mainJ);
	}

	

}
