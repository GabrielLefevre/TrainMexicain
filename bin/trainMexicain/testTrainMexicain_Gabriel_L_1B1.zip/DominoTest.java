package trainMexicain;

import static org.junit.Assert.*;

import org.junit.Test;

public class DominoTest {

	@Test
	public void testDomino() {
		Domino d = new Domino(0, 0);
		assertEquals(d.getPartG(),0);
		assertEquals(d.getPartD(),0);
	}


	@Test
	public void testGetPartD() {
		Domino d = new Domino(1,3);
		assertEquals(d.getPartD(),3);
	}

	@Test
	public void testGetPartG() {
		Domino d = new Domino(1,3);
		assertEquals(d.getPartG(),1);
	}

	@Test
	public void testEstDouble() {
		Domino d = new Domino(4,4);
		assertEquals(d.getPartG(),4);
		assertEquals(d.getPartD(),4);
	}

	@Test
	public void testPeutEtrePlaceApres() {
		Domino d = new Domino(5,8);
		Domino d2 = new Domino(8,2);
		assertTrue(d.peutEtrePlaceApres(d2));
	}


	@Test
	public void testPermuterDomino() {
		Domino d = new Domino(8,4);
		d.permuterDomino();
		assertEquals(d.getPartG(),4);
	}

}
